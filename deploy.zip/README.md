#fe-react-cobranca

Project gerado pela pipe.

## Apos criação

Para deixar o projeto apto é necessário ajustar a branch principal(main).

## Projetos

A branch main deve ter o arquivo de build pom.xml se for maven e seus diretórios básicos. Caso for Gradle build.gradle. Os projetos “node/js e .net” seguem a mesma ideia, porém com suas configurações corretas.
OBS: Branch main deve estar minimamente apta para realizar o build.

## Build ci/cd

No projeto existe o arquivo .gitlab/ci_cd.yml, nele é necessario add o comando básico de build da app.

No arquivo gerado .gitlab/ci_cd.yml contem a tag "**BUILD_COMMAND**", está que deve ser substituida pelo comando de build.

#### OBS

Devido a necessidade do Sonar, os comandos de Build serão tratados no arquivo da Pipeline (/.gitlab/ci_cd.yml) , juntamente com o nome da Imagem utilizada para o Build. (Obs. não é imagem utilizada na execução da App)

Exemplo do comando:

```bash
    mvn --settings settings_nexus.xml -P nexus clean package -DskipTests
```

## Docker Img

A docker img definida no arquivo .gitlab/ci_cd.yml deve ser a que o projeto irá utilizar, no caso a mesma que à do Dockerfile.
Substitua a tag "**DOCKER_IMG**" pela imagem a ser utilizada.

### Arquivo .gitlab/ci_cd.yml onde terá que ajustar o build command e docker img

![COMANDO DO BUILD](https://git.cvc.com.br/architecture/processors/execute-process-pipe/-/raw/main/resources/defaults/ilustracao-1.png)

## Documentação

[Documentação nova pipeline](https://cvccorp.atlassian.net/wiki/external/ZTk0YTVlNGM3NmZkNGEyNmJhZDYxNGZkMzgyNzcyODc)
