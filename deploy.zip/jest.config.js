const jestConfig = require("@cvccorp-components/chui-testing/config").default;


const config = jestConfig({
  setupFilesAfterEnv: ["@cvccorp-components/chui-testing/setup"],
});

module.exports = config;
