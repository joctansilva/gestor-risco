import React from 'react';
import { makeRemoteGetAllSystem } from '../usecases/system/make-remote-system';
import SystemPage from '@/presentation/pages/System/system';

const MakeSystem = () => {
  return <SystemPage getAll={makeRemoteGetAllSystem()} />;
};

export default MakeSystem;
