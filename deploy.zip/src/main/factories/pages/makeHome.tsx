import Home from '@/presentation/pages/Home/home';
import React from 'react';

const MakeHome = () => {
  return <Home />;
};

export default MakeHome;
