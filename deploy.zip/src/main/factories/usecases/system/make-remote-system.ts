import { makeApiUrlAdapter } from '@/main/adapter';
import { makeAxiosHttpClientAdapter } from '../../http';
import { IGetAllSystem } from '@/domain/usecases/system/system';
import { RemoteGetAllSystem } from '@/data/usecases/system/remote-getAllSystem';

export const makeRemoteGetAllSystem = (): IGetAllSystem => {
  return new RemoteGetAllSystem(
    makeApiUrlAdapter().getUrl('/systems'),
    makeAxiosHttpClientAdapter(),
  );
};
