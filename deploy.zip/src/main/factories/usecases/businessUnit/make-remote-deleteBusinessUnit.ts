import { RemoteDeleteBusinessUnit } from '@/data/usecases/businessUnit';
import { IDeleteBusinessUnit } from '@/domain/usecases/businessUnit';
import { makeApiUrlAdapter } from '@/main/adapter';
import { makeAxiosHttpClientAdapter } from '../../http';

export const makeRemoteDeleteBusinessUnit = (): IDeleteBusinessUnit => {
  return new RemoteDeleteBusinessUnit(
    makeAxiosHttpClientAdapter(),
    makeApiUrlAdapter().getUrl('/businessUnit/{id}'),
  );
};
