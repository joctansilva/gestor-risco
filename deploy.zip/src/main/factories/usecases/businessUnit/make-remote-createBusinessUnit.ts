import { RemoteCreateBusinessUnit } from '@/data/usecases/businessUnit';
import { ICreateBusinessUnit } from '@/domain/usecases/businessUnit';
import { makeApiUrlAdapter } from '@/main/adapter';
import { makeAxiosHttpClientAdapter } from '../../http';

export const makeRemoteCreateBusinessUnit = (): ICreateBusinessUnit => {
  return new RemoteCreateBusinessUnit(
    makeAxiosHttpClientAdapter(),
    makeApiUrlAdapter().getUrl('/businessUnit'),
  );
};
