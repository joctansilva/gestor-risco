import { RemoteGetUniqueBusinessUnit } from '@/data/usecases/businessUnit';
import { IGetUniqueBusinessUnit } from '@/domain/usecases/businessUnit';
import { makeApiUrlAdapter } from '@/main/adapter';
import { makeAxiosHttpClientAdapter } from '../../http';

export const makeRemoteGetUniqueBusinessUnit = (): IGetUniqueBusinessUnit => {
  return new RemoteGetUniqueBusinessUnit(
    makeAxiosHttpClientAdapter(),
    makeApiUrlAdapter().getUrl('/businessUnit/{id}'),
  );
};
