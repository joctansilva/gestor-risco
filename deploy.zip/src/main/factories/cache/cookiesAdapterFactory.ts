import { CookieAdapter } from '@/infra/cache';

export const makeCookieAdapter = (): CookieAdapter => new CookieAdapter();
