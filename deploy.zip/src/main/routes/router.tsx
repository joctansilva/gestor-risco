import { createBrowserRouter, Navigate } from 'react-router-dom';
import React from 'react';
import PublicRoute from '../proxies/publicRoute';
import Layout from '@/presentation/components/Layout';
import PrivateRoute from '../proxies/privateRoute';
import MakeHome from '../factories/pages/makeHome';
import MakeSystem from '../factories/pages/makeSystem';

const router = createBrowserRouter([
  {
    id: 'select_business_unit',
    element: <Layout />,
    children: [
      {
        path: '/',
        element: <PublicRoute Component={<MakeSystem />} />,
      },
    ],
    errorElement: <Navigate to="/" />,
  },
  {
    id: 'home',
    element: <Layout />,
    loader: () => {
      return {
        name: 'home',
      };
    },
    children: [
      {
        path: '/home',
        element: <PrivateRoute Component={<MakeHome />} />,
      },
    ],
  },
]);

export default router;
