import { backofficeLogin } from '@/app/constants/default';
import { useCookie } from '@/presentation/hooks/useCookie';
import { IRoute } from './privateRoute';

const PublicRoute = ({ Component }: IRoute) => {
  const cookie = useCookie();

  // return cookie ? Component : (window.location.href = backofficeLogin);
  return Component;
};

export default PublicRoute;
