import {
  IHttpClient,
  IHttpResponse,
  THttpRequest,
} from '@/data/protocols/http';
import axios, { AxiosResponse } from 'axios';

export interface IResponse {
  totalElements: number;
  currentPage: number;
  totalPages: number;
  pageSize: number;
}

export class AxiosHttpClient implements IHttpClient {
  async request(data: THttpRequest): Promise<IHttpResponse> {
    let axiosReponse: AxiosResponse;
    try {
      axiosReponse = await axios.request({
        url: data.url,
        method: data.method,
        data: data.body,
        headers: data.headers,
      });
    } catch (error) {
      axiosReponse = error.response;
    }
    return {
      statusCode: axiosReponse.status,
      body: axiosReponse.data,
      error: axiosReponse.data,
    };
  }
}
