export * from './cookieAdapter';
