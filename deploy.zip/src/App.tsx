import React from 'react';
import { GlobalStyles } from '@/presentation/styles/globalStyles';
import {
  ChuiThemeProvider,
  Toast,
  ToastProvider,
} from '@cvccorp-components/chui-react-components';
import '@cvccorp-components/chui-react-components/assets/css/chui.css';
import { Global } from '@emotion/react';
import {
  QueryCache,
  QueryClient,
  QueryClientProvider,
} from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import router from '@/main/routes/router';
import { RouterProvider } from 'react-router-dom';

const Main = () => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        refetchOnReconnect: false,
        retry: 1,
        staleTime: 5 * (60 * 1000),
        gcTime: 10 * (60 * 1000),
      },
    },
    queryCache: new QueryCache({
      onError: () => {
        Toast.danger({
          title:
            'Não foi possível carregar as informações. Tente novamente mais tarde.',
        });
      },
    }),
  });

  return (
    <QueryClientProvider client={queryClient}>
      <ChuiThemeProvider>
        <Global styles={GlobalStyles} />
        <ToastProvider
          id="default-toast"
          variant="filled"
          position="top-right"
          timeout={4000}
        />
        <RouterProvider router={router} />
        <ReactQueryDevtools initialIsOpen />
      </ChuiThemeProvider>
    </QueryClientProvider>
  );
};

export default Main;
