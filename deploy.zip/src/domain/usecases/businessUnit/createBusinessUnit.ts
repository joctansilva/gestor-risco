import { IBusinessUnit } from '@/domain/models';

export interface ICreateBusinessUnit {
  create(data: IBusinessUnit): Promise<IBusinessUnit>;
}
