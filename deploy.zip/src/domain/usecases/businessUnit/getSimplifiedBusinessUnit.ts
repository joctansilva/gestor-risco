import { TSimplifiedBusinessUnit } from '@/domain/models';

export interface IGetSimplifiedBusinessUnit {
  get(): Promise<TSimplifiedBusinessUnit[]>;
}
