import { IBusinessUnitResponse } from '@/domain/models';

export interface IGetAllBusinessUnit {
  get(params: string): Promise<IBusinessUnitResponse>;
}
