import { IBusinessUnit } from "@/domain/models";

export interface IGetUniqueBusinessUnit {
  get(id: number): Promise<IBusinessUnit>
}