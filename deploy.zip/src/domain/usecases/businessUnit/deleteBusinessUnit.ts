export interface IDeleteBusinessUnit {
  delete(id: number): Promise<void>;
}
