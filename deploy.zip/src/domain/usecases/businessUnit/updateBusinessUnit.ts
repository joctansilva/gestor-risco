import { IBusinessUnit } from '@/domain/models';

export interface IUpdateBusinessUnit {
  update(data: IBusinessUnit): Promise<IBusinessUnit>;
}
