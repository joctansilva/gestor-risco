import { ISystemResponse } from '@/domain/models';

export interface IGetAllSystem {
  get(): Promise<ISystemResponse>;
}
