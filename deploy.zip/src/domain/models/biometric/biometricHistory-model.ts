export interface IBiometricHistory {
  id: number;
  analysisBiometricsId: number;
  biometricStatus: string;
  username: string;
  createdAt: string;
}

export type IBiometricHistoryResponse = IBiometricHistory[];
