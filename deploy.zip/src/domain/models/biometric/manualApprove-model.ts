import { IResponse } from '@/infra/http';

export interface IManualApproval {
  manualApprovalId: number;
  clientName: string | null;
  clientDocument: string;
  systemId: number;
  userReleased: string;
  loginReleased: string;
  createdAt: string;
  status: string;
  bookings: number[];
}

export interface IManualApprovalResponse extends IResponse {
  results: IManualApproval[];
}
