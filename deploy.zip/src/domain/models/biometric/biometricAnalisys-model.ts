import { IResponse } from '@/infra/http';

export interface IBiometricAnalysis {
  id: number;
  systemId: number;
  clientName: string;
  clientDocument: string;
  externalReference: string;
  branchName: string;
  branchCode: number;
  statusBiometrics: string;
  rank: number;
  linkSerasa: string;
  serasaCode: string;
  unit: number;
  createdAt: string;
  updatedAt: string;
  username: string;
  bookings: number[];
}

export interface IBiometricAnalysisResponse extends IResponse {
  results: IBiometricAnalysis[];
}
