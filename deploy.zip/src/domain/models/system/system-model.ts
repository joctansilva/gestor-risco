import { IResponse } from '@/infra/http';

export interface ISystem {
  sqSystem: number;
  dsSystem: string;
  stActive: boolean;
}

export interface ISystemResponse extends IResponse {
  results: ISystem[];
}
