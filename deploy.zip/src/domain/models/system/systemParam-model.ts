export interface ISystemParams {
  sqSystem: number;
  nrApprovalRanking: number | null;
  stActiveBiometrics: boolean | null;
  stSendSms: boolean;
  workflowId: number | null;
  userConsultSerasa: string;
  passConsultSerasa: string;
  userRecognitionSerasa: string;
  passRecognitionSerasa: string;
  nmUser: string;
}
