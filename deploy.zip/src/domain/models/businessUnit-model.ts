import { IResponse } from '@/infra/http';

export interface IBusinessUnit {
  id?: number;
  cd_unit?: number;
  ds_name: string;
  nm_corp_reason?: string | null;
  nr_cnpj: string;
  channel?: string;
  updated_at?: string;
  updated_by?: string;
  st_active: boolean;
}

export interface IBusinessUnitResponse extends IResponse {
  results: IBusinessUnit[];
}

export type TSimplifiedBusinessUnit = {
  id?: number;
  nm_corp_reason: string;
  cd_unit?: number;
  st_active: boolean;
};
