import { IMessage } from "@/data/protocols/http";

export class HandleError extends Error {
  constructor(public httpCode: number, public name: string, public error?: IMessage) {
    super()
    this.error = error
    this.httpCode = httpCode
    this.name = name
  }
}