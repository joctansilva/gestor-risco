import {
  removeCurrentCookie,
  setCurrentCookie,
} from '@/main/adapter/currentCookieAdapter';
import { useNavigate } from 'react-router-dom';

export const useLogout = () => {
  const navigate = useNavigate();

  const privateLogout = () => {
    setCurrentCookie();
    navigate('/', { replace: true });
  };

  const publicLogout = () => {
    removeCurrentCookie();
    window.location.reload();
  };

  return { privateLogout, publicLogout };
};
