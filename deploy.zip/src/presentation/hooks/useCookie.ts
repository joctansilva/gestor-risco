import { getCurrentCookie } from '@/main/adapter/currentCookieAdapter';
import { jwtDecode } from 'jwt-decode';

export interface ICookie {
  aud: string;
  authorities: Array<string>;
  default_context: string;
  exp: number;
  iat: number;
  iss: string;
  nbf: number;
  scope: Array<string>;
  sub: string;
  sq_unit: number;
  nm_corp_reason: string;
}

export const useCookie = (): ICookie | undefined => {
  const encodedCookie = getCurrentCookie();
  if (encodedCookie) {
    return jwtDecode(encodedCookie);
  }
};
