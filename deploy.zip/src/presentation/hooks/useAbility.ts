import defineAbilityFor from '@/permissions/abilities';
import { useCookie } from './useCookie';

export const useAbility = (subject: string) => {
  const cookie = useCookie();
  const ability = defineAbilityFor(String(cookie?.scope.toString()));
  // const ability = defineAbilityFor('SCOPE_COCKPIT_BUSINESS');
  // const ability = defineAbilityFor('SCOPE_COCKPIT_SEARCH');
  const canRead = ability.can('read', subject);
  const canCreate = ability.can('create', subject);
  const canUpdate = ability.can('update', subject);
  const canDelete = ability.can('delete', subject);
  const canUpdateCredentials = ability.can('updateCredentials', subject);
  return { canRead, canCreate, canUpdate, canDelete, canUpdateCredentials };
};
