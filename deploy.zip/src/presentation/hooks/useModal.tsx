import { Modal } from '@cvccorp-components/chui-react-components';
import React, { useState } from 'react';

interface IDefaultModal {
  width?: string;
  height?: string;
  modalTitle: string;
  content: JSX.Element;
  id?: string;
}

export const useModal = () => {
  const [openDefaultModal, setOpenDefaultModal] = useState<boolean>(false);

  const DefaultModal = ({
    width,
    height,
    modalTitle,
    content,
    id,
  }: IDefaultModal) => {
    return (
      <>
        <Modal
          id={id}
          width={width ? width : '750px'}
          height={height ? height : '500px'}
          open={openDefaultModal}
          onClose={handleCloseDefaultModal}
          onCancel={handleCloseDefaultModal}
          title={modalTitle}
          renderFooter={() => (
            <div style={{ padding: '1rem 1.5rem', height: '4.75rem' }} />
          )}
        >
          {content}
        </Modal>
      </>
    );
  };

  const handleOpenDefaultModal = () => setOpenDefaultModal(true);

  const handleCloseDefaultModal = () => setOpenDefaultModal(false);

  return {
    DefaultModal,
    handleOpenDefaultModal,
    handleCloseDefaultModal,
  };
};
