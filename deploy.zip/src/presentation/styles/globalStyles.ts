import { css } from '@emotion/react';

export const GlobalStyles = css`
  html,
  body {
    padding: 0;
    margin: 0;
  }
  * {
    box-sizing: border-box;
    font-family: 'Nunito' !important;
  }
  body {
    background: #f6f6ff;
  }
  .lucide {
    fill: none !important;
  }
  #remove-modal {
    min-height: 0 !important;
  }
  .chui-modal__scrollbar {
    padding: 1rem 1.5rem !important;
  }
  #default-toast {
    z-index: 1000 !important;
  }
  td {
    &:empty::before {
      content: '-';
    }
  }
  td,
  th {
    text-align: center;
  }
`;
