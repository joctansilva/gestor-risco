import styled from '@emotion/styled';

export const Card = styled.div`
  box-shadow: 0 1px 4px rgba(0, 0, 20, 0.12);
  border-radius: 1rem;
  background: #fff;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: flex-start;
  padding: 1rem;
  isolation: isolate;
  position: relative;
  width: 15rem;
  height: 6rem;
  cursor: pointer;
  & label {
    cursor: pointer;
  }
  &:hover {
    box-shadow: 0px 4px 16px rgba(0, 0, 20, 0.32);
  }
  &:active {
    background: #0a00b4;
    & label {
      color: #fff;
    }
    & span {
      background: #050091;
    }
  }
`;

export const TitleContainer = styled.div`
  width: 55%;
`;

export const IconContainer = styled.div`
  display: flex;
  justify-content: center;
  flex-direction: row;
  align-items: center;
  padding: 0.75rem;
  width: 4rem;
  height: 4rem;
  background: #b4b4f0;
  border-radius: 0.5rem;
  position: absolute;
  left: 9.5rem;
  right: 0;
  top: 1rem;
  bottom: 1rem;
  z-index: 1;
`;

export const Square = styled.span`
  position: absolute;
  width: 5rem;
  height: 2.75rem;
  left: 9rem;
  right: 0;
  bottom: 0;
  background: #efeffd;
  border-radius: 0.5rem 0.5rem 0 0;
  z-index: 0;
`;
