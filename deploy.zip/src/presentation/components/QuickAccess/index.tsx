import { Typography } from '@cvccorp-components/chui-react-components';
import React from 'react';
import { useNavigate } from 'react-router';
import { TNavBarItems } from '../NavBar';
import * as S from './styles';

interface IQuickAccess extends Omit<TNavBarItems, 'alternativeIcon'> {}

const QuickAcess = ({ label, path, icon }: IQuickAccess) => {
  const navigate = useNavigate();
  return (
    <S.Card onClick={() => navigate(path)}>
      <S.TitleContainer>
        <Typography
          variant="label"
          scale={6}
          weight="bold"
          color="neutral.black"
        >
          {label}
        </Typography>
      </S.TitleContainer>
      <S.IconContainer>{icon}</S.IconContainer>
      <S.Square />
    </S.Card>
  );
};

export default QuickAcess;
