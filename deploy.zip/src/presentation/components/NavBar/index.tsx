import { useAbility, useLogout } from '@/presentation/hooks';
import { useCookie } from '@/presentation/hooks/useCookie';
import { Button, Typography } from '@cvccorp-components/chui-react-components';
import {
  ArrowLeftRightIcon,
  CreditCard,
  ReceiptText,
  Settings,
  Store,
  Unplug,
} from 'lucide-react';
import React from 'react';
import { useLocation, useNavigate, useRouteLoaderData } from 'react-router';
import * as S from './styles';

export type TNavBarItems = {
  label: string;
  path: string;
  pageGroup?: string;
  icon: JSX.Element;
  alternativeIcon: JSX.Element;
  visible?: boolean;
};

export interface IHomeLoaderData {
  name: string;
}

export interface IMainLoaderData extends IHomeLoaderData {
  hasNavBarItems: boolean;
}

const NavBar = () => {
  const { canRead: canReadBusinessUnit } = useAbility('BusinessUnit');
  const { canRead: canReadPolicies } = useAbility('Policies');
  const { canRead: canReadBankSlip } = useAbility('BankSlip');
  const { canRead: canReadGeneralParameters } = useAbility('GeneralParameters');
  const { canUpdate: canIntegrateBillingManager } =
    useAbility('BillingManager');

  const navBarItems: TNavBarItems[] = [
    {
      label: 'Parâmetros Gerais',
      path: '/parametros-gerais/configurar-parametro',
      pageGroup: 'parametros-gerais',
      icon: <Settings color="white" />,
      alternativeIcon: <Settings color="#4d4d5e" />,
      visible: canReadGeneralParameters,
    },
    {
      label: 'Geração de Boletos',
      path: '/geracao-de-boletos/bancos',
      pageGroup: 'geracao-de-boletos',
      icon: <CreditCard color="white" />,
      alternativeIcon: <CreditCard color="#4d4d5e" />,
      visible: canReadBankSlip,
    },
    {
      label: 'Cadastro Unidade de Negócios',
      path: '/cadastro-unidade-de-negocios',
      pageGroup: 'cadastro-unidade-de-negocios',
      icon: <Store color="white" />,
      alternativeIcon: <Store color="#4d4d5e" />,
      visible: canReadBusinessUnit,
    },
    {
      label: 'Políticas',
      path: '/politicas/score-serasa',
      pageGroup: 'politicas',
      icon: <ReceiptText color="white" />,
      alternativeIcon: <ReceiptText color="#4d4d5e" />,
      visible: canReadPolicies,
    },
    {
      label: 'Integração Gerenciador de Cobranças',
      path: '/integracao-gerenciador-de-cobrancas',
      pageGroup: 'integracao-gerenciador-de-cobrancas',
      icon: <Unplug color="white" />,
      alternativeIcon: <Unplug color="#4d4d5e" />,
      visible: canIntegrateBillingManager,
    },
  ];

  const navigate = useNavigate();
  const { pathname } = useLocation();
  const { privateLogout } = useLogout();
  const cookie = useCookie();

  const homeLoaderData = useRouteLoaderData('home') as IHomeLoaderData;
  const mainLoaderData = useRouteLoaderData('main') as
    | IMainLoaderData
    | undefined;

  return (
    <S.NavBarWrapper>
      <S.NavBarContainer>
        <>
          <S.TitleContainer>
            <Typography
              variant="headline"
              weight="bold"
              style={{ fontSize: '32px' }}
            >
              Cockpit de parametrizações
            </Typography>
            {(homeLoaderData || mainLoaderData) && (
              <S.BusinessUnitContainer>
                <div>
                  <Typography variant="paragraph" scale={2}>
                    Unidade de Negócio:
                  </Typography>
                  <Typography variant="headline" scale={7} weight="bold">
                    {cookie?.nm_corp_reason}
                  </Typography>
                </div>
                <div>
                  <Button
                    onClick={() => privateLogout()}
                    size="sm"
                    variant="filled"
                    color="secondary"
                    icon={<ArrowLeftRightIcon color="white" strokeWidth={2} />}
                  />
                </div>
              </S.BusinessUnitContainer>
            )}
          </S.TitleContainer>
          {mainLoaderData?.hasNavBarItems && (
            <S.NavBarItemsContainer>
              {navBarItems.map(item => {
                const splittedPathname = pathname.split('/');
                const validation = item.pageGroup === splittedPathname[1];
                return (
                  item.visible && (
                    <Button
                      key={item.label}
                      variant={validation ? 'filled' : 'text'}
                      color={validation ? 'secondary' : 'neutral'}
                      icon={validation ? item.icon : item.alternativeIcon}
                      onClick={() => {
                        navigate(item.path);
                      }}
                    >
                      {item.label}
                    </Button>
                  )
                );
              })}
            </S.NavBarItemsContainer>
          )}
        </>
      </S.NavBarContainer>
    </S.NavBarWrapper>
  );
};

export default NavBar;
