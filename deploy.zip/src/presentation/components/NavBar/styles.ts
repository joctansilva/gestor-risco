import styled from '@emotion/styled';
import { Container } from '../Layout/styles';

export const NavBarWrapper = styled.div`
  width: 100%;
  background: #fff;
`;

export const NavBarContainer = styled(Container)`
  padding: 0 3.5rem 2rem;
`;

export const TitleContainer = styled.div`
  padding: 48px 0 24px;
  display: flex;
  justify-content: space-between;
`;

export const BusinessUnitContainer = styled.div`
  display: flex;
  flex-direction: row;
  gap: 1.5rem;
  align-items: center;
`;

export const NavBarItemsContainer = styled.div`
  display: flex;
  border: 0.125rem solid #d6d6e6;
  border-radius: 0.75rem;
  padding: 0.25rem;
  gap: 0.25rem;
  & button {
    padding: 0 1rem;
    min-width: 200px;
  }
`;
