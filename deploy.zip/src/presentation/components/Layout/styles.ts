import styled from '@emotion/styled';

export const Container = styled.div`
  max-width: 90rem;
  margin: 0 auto;
  padding: 1rem 3.5rem 2rem;
`;
