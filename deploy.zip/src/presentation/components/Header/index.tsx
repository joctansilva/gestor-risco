import Logo from '@/presentation/components/Logo';
import { useLogout } from '@/presentation/hooks';
import { useCookie } from '@/presentation/hooks/useCookie';
import {
  Avatar,
  Button,
  Typography,
} from '@cvccorp-components/chui-react-components/components';
import { LogOut } from 'lucide-react';
import React from 'react';
import { useNavigate } from 'react-router-dom';
import * as S from './styles';

const Header = () => {
  const navigate = useNavigate();
  const cookie = useCookie();
  const { publicLogout } = useLogout();

  const businessUnit = cookie?.nm_corp_reason;
  const user = cookie?.sub;
  const userUpper = user?.toUpperCase();
  const userInitials0 = userUpper?.substring(0, 1);
  const userInitials1 = userUpper?.substring(userUpper.length - 1);

  return (
    <>
      <S.HeaderContainer>
        <S.HeaderWrapper>
          <S.LogoWrapper onClick={() => navigate('/home')}>
            <Logo theme="light" />
            <p style={{ color: '#ffffff', fontSize: '1.25rem' }}>
              Gestor de Risco
            </p>
          </S.LogoWrapper>
          <div>
            <Avatar size="lg" variant="circle" color="secondary">
              <span
                style={{ color: '#05004B ' }}
              >{`${userInitials0}${userInitials1}`}</span>
            </Avatar>
            <p style={{ color: '#ffffff', fontSize: '1rem' }}>{user}</p>
            <Button
              onClick={() => publicLogout()}
              size="sm"
              color="primary"
              icon={<LogOut color="#05004B" />}
            />
          </div>
        </S.HeaderWrapper>
      </S.HeaderContainer>
    </>
  );
};

export default Header;
