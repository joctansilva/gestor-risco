import { ChuiTheme } from '@cvccorp-components/chui-react-components';
import styled from '@emotion/styled';

export const HeaderContainer = styled.div<{ theme?: ChuiTheme }>(props => {
  const colors = props.theme.colors;
  return {
    background: colors.brand.secondary[500],
    height: '5.5rem',
    width: '100%',
  };
});

export const HeaderWrapper = styled.div<{ theme?: ChuiTheme }>(props => {
  const colors = props.theme.colors;
  return {
    alignItems: 'center',
    background: colors.transparent,
    display: 'flex',
    height: '100%',
    justifyContent: 'space-between',
    margin: '0 auto',
    maxWidth: '90rem',
    padding: '0 3rem',
    width: '100%',

    '& > div': {
      alignItems: 'center',
      display: 'flex',
      gap: '1.5rem',
      justifyContent: 'center',
    },
    '& > div:nth-of-type(2n)': {
      gap: '1.125rem',
    },
    '& h6, & p': {
      color: '#05004B',
    },
  };
});

export const LogoWrapper = styled.div`
  cursor: pointer;
`;
