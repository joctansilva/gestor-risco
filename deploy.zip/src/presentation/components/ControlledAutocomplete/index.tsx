import { IOptions } from '@/presentation/pages';
import { Autocomplete } from '@cvccorp-components/chui-react-components';
import { Controller } from '@cvccorp-components/chui-react-form';
import React from 'react';
import { IControlledInput } from '../ControlledInput';
import * as S from './styles';

interface IControlledAutocomplete extends IControlledInput {
  options: IOptions[];
}

const ControlledAutocomplete = ({
  name,
  control,
  label,
  options,
  supportText,
  disabled,
}: IControlledAutocomplete) => {
  return (
    <Controller
      name={name}
      control={control}
      render={({ field: { onChange, onBlur, value } }) => (
        <Autocomplete
          label={label}
          onSelect={onChange}
          onBlur={onBlur}
          value={value}
          options={options}
          supportText={
            <>
              {supportText}
              <span />
            </>
          }
          disabled={disabled}
          renderOption={({ option: { status, label } }) => (
            <S.CustomOption>
              {status && (
                <S.CustomBadgeStatus color={status ? 'success' : 'danger'} />
              )}
              {label}
            </S.CustomOption>
          )}
        />
      )}
    />
  );
};

export default ControlledAutocomplete;
