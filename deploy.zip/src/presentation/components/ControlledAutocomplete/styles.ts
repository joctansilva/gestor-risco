import {
  Autocomplete,
  BadgeStatus,
} from '@cvccorp-components/chui-react-components';
import styled from '@emotion/styled';

export const CustomOption = styled(Autocomplete.Option)`
  justify-content: flex-start;
`;

export const CustomBadgeStatus = styled(BadgeStatus)`
  aspect-ratio: 1/1;
`;
