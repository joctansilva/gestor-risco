import styled from '@emotion/styled';

export const FooterContainer = styled.div`
  display: flex;
  justify-content: center;
  flex-direction: row;
  padding: 1.5rem;
`;
