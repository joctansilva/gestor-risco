import { Input, InputProps } from '@cvccorp-components/chui-react-components';
import { Control, Controller } from '@cvccorp-components/chui-react-form';
import React, { ReactNode } from 'react';

export interface IControlledInput extends Omit<InputProps, 'defaultValue'> {
  name: string;
  control?: Control<any>;
  label: string;
  supportText?: ReactNode;
}

const ControlledInput = ({
  name,
  control,
  label,
  supportText,
  ...props
}: IControlledInput) => {
  return (
    <Controller
      name={name}
      control={control}
      render={({ field: { onChange, onBlur, value } }) => {
        return (
          <Input
            {...props}
            label={label}
            onChange={e => onChange(e.target.value || undefined)}
            onBlur={onBlur}
            value={value}
            status={supportText ? 'danger' : undefined}
            supportText={
              <>
                {supportText}
                <span />
              </>
            }
          />
        );
      }}
    />
  );
};

export default ControlledInput;
