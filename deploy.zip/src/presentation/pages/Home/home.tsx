import { TNavBarItems } from '@/presentation/components';
import QuickAcess from '@/presentation/components/QuickAccess';
import { useAbility } from '@/presentation/hooks';
import { Typography } from '@cvccorp-components/chui-react-components';
import { CreditCard, ReceiptText, Settings, Store, Unplug } from 'lucide-react';
import React from 'react';
import * as S from './styles';

const Home = () => {
  const { canRead: canReadBusinessUnit } = useAbility('BusinessUnit');
  const { canRead: canReadPolicies } = useAbility('Policies');
  const { canRead: canReadBankSlip } = useAbility('BankSlip');
  const { canRead: canReadGeneralParameters } = useAbility('GeneralParameters');
  const { canUpdate: canIntegrateBillingManager } =
    useAbility('BillingManager');

  let quickAcessItems: Omit<TNavBarItems, 'alternativeIcon'>[] = [
    {
      label: 'Parâmetros Gerais',
      path: '/parametros-gerais/configurar-parametro',
      icon: <Settings size={40} color="#fff" />,
      visible: canReadGeneralParameters,
    },
    {
      label: 'Geração de Boletos',
      path: '/geracao-de-boletos/bancos',
      icon: <CreditCard size={40} color="#fff" />,
      visible: canReadBankSlip,
    },
    {
      label: 'Cadastro de Unidade de Negócios',
      path: '/cadastro-unidade-de-negocios',
      icon: <Store size={40} color="#fff" />,
      visible: canReadBusinessUnit,
    },
    {
      label: 'Políticas',
      path: '/politicas',
      icon: <ReceiptText size={40} color="#fff" />,
      visible: canReadPolicies,
    },
    {
      label: 'Integraçao Gerenciador de Cobranças',
      path: '/integracao-gerenciador-de-cobrancas',
      icon: <Unplug size={40} color="#fff" />,
      visible: canIntegrateBillingManager,
    },
  ];

  return (
    <S.Wrapper>
      <S.TitleContainer>
        <Typography
          variant="headline"
          scale={6}
          weight="bold"
          color="brand.secondary.700"
        >
          Acesso rápido
        </Typography>
      </S.TitleContainer>
      <S.CardContainer>
        {quickAcessItems.map(item => {
          return (
            item.visible && (
              <QuickAcess
                key={item.label}
                label={item.label}
                path={item.path}
                icon={item.icon}
              />
            )
          );
        })}
      </S.CardContainer>
    </S.Wrapper>
  );
};

export default Home;
