import styled from '@emotion/styled';

export const Wrapper = styled.div`
  width: 90.25rem;
  margin: 0 auto;
  max-width: 100%;
`;

export const TitleContainer = styled.div`
  padding: 0 0 1.5rem;
`;

export const CardContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.625rem 0.59375rem;
`;
