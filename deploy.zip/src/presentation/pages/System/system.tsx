import { IGetAllSystem } from '@/domain/usecases/system/system';
import { editCurrentCookie } from '@/main/adapter/currentCookieAdapter';
import ControlledAutocomplete from '@/presentation/components/ControlledAutocomplete';
import Logo from '@/presentation/components/Logo';
import { useCookie } from '@/presentation/hooks/useCookie';
import { selectSystemSchema, TSelectSystemSchema } from '@/validation';

import { Button } from '@cvccorp-components/chui-react-components';
import { useForm } from '@cvccorp-components/chui-react-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useQuery } from '@tanstack/react-query';
import React from 'react';
import { useNavigate } from 'react-router';
import * as S from './styles';

interface ISystemPage {
  getAll: IGetAllSystem;
}

export interface IOptions {
  label: string;
  value: string;
  status?: boolean;
}

const SystemPage = ({ getAll }: ISystemPage) => {
  const cookie = useCookie();
  const navigate = useNavigate();

  const { data: selectData, isFetching: loading } = useQuery({
    queryKey: ['selectSystem'],
    queryFn: () => getAll.get(),
    staleTime: 1000,
    gcTime: 2000,
  });

  let options: IOptions[] = [];
  if (selectData) {
    options = selectData.results.map(data => {
      return {
        label: data.dsSystem,
        value: `${data.sqSystem}-${data.dsSystem}`,
        status: data.stActive,
      };
    });
  }

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<TSelectSystemSchema>({
    resolver: zodResolver(selectSystemSchema),
  });

  const onSubmit = (data: any) => {
    const systemData = data.select_system.split('-');
    const newCookie = {
      ...cookie,
      sq_system: Number(systemData[0]),
      ds_system: systemData[1],
    };
    const encodedNewCookie = btoa(JSON.stringify(newCookie));
    editCurrentCookie(encodedNewCookie);
    navigate('/home');
  };

  return (
    <S.Wrapper>
      <S.Container>
        <S.Card>
          <S.LogoWrapper>
            <Logo theme="dark" />
          </S.LogoWrapper>
          <S.Form onSubmit={handleSubmit(onSubmit)}>
            <ControlledAutocomplete
              name="select_system"
              control={control}
              label="Selecione o Sistema"
              options={options}
              disabled={loading}
              supportText={errors.select_system && errors.select_system.message}
            />
            <Button type="submit" loading={loading}>
              Entrar
            </Button>
          </S.Form>
        </S.Card>
      </S.Container>
    </S.Wrapper>
  );
};

export default SystemPage;
