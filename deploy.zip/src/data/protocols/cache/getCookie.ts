export interface IGetCookie {
  get: (key: string) => string | undefined;
}
