export interface IEditCookie {
  edit: (key: string, value: string) => void;
}
