import Cookies from 'js-cookie';

export interface ISetCookie {
  set: (key: string, value: string, options?: Cookies.CookieAttributes) => void;
}
