export interface IMessage {
  mensagens: TMensagem[];
  causa: string;
}

export type TMensagem = {
  mensagem: string;
};

export type THttpMethod = 'get' | 'post' | 'put' | 'delete' | 'patch';

export type THttpRequest = {
  url: string;
  method: THttpMethod;
  body?: any;
  headers?: any;
  responseType?: 'json' | 'blob' | 'arraybuffer';
};

export enum EHttpStatusCode {
  ok = 200,
  created = 201,
  noContent = 204,
  badRequest = 400,
  unauthorized = 401,
  forbidden = 403,
  notFound = 404,
  methodNotAllowed = 405,
  notAcceptable = 406,
  serverError = 500,
  serviceUnavailable = 503,
}

export interface IHttpResponse<Response = any> {
  headers: any;
  statusCode: EHttpStatusCode;
  error?: IMessage;
  body?: Response;
}

export interface IHttpClient<Response = any> {
  request: (data: THttpRequest) => Promise<IHttpResponse<Response>>;
}
