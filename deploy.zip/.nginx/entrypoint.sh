#!/bin/sh

environments=$(env | grep "^VITE_*")
echo "window.env = {" > /usr/share/nginx/html/env-config.js
replace=": \""
delimite="="
for ENVIRONEMT in ${environments}; do
  if [ "$ENVIRONEMT" ]; then
    VALUE=$(echo $ENVIRONEMT | sed -e "s/${delimite}/${replace}/g")
    echo "  ${VALUE}\"," >> /usr/share/nginx/html/env-config.js
  fi
done
echo "}" >> /usr/share/nginx/html/env-config.js

nginx -g 'daemon off;'