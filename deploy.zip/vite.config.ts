import {
  reactTsSPAVitePreset,
  vitePluginHtmlChuiMeta,
} from '@cvccorp-components/chui-vite';

export default reactTsSPAVitePreset({
  plugins: [vitePluginHtmlChuiMeta()],
});
