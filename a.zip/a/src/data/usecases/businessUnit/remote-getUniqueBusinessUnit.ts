import { EHttpStatusCode, IHttpClient } from '@/data/protocols/http';
import { HandleError } from '@/domain/errors';
import { IBusinessUnit } from '@/domain/models';
import { IGetUniqueBusinessUnit } from '@/domain/usecases/businessUnit';

export class RemoteGetUniqueBusinessUnit implements IGetUniqueBusinessUnit {
  private readonly httpClient: IHttpClient<IBusinessUnit>;
  private readonly url: string;

  constructor(httpClient: IHttpClient, url: string) {
    this.httpClient = httpClient;
    this.url = url;
  }

  async get(id: number): Promise<IBusinessUnit> {
    const response = await this.httpClient.request({
      method: 'get',
      url: this.url.replace('{id}', id.toString()),
    });
    switch (response.statusCode) {
      case EHttpStatusCode.ok:
        return response.body!;
      case EHttpStatusCode.badRequest:
        throw new HandleError(
          response.statusCode,
          'BadRequestError',
          response.error,
        );
      case EHttpStatusCode.unauthorized:
        throw new HandleError(
          response.statusCode,
          'UnauthorizedError',
          response.error,
        );
      case EHttpStatusCode.forbidden:
        throw new HandleError(
          response.statusCode,
          'ForbiddenError',
          response.error,
        );
      case EHttpStatusCode.notFound:
        throw new HandleError(
          response.statusCode,
          'NotFoundError',
          response.error,
        );
      case EHttpStatusCode.methodNotAllowed:
        throw new HandleError(
          response.statusCode,
          'methodNotAllowedError',
          response.error,
        );
      case EHttpStatusCode.serverError:
        throw new HandleError(
          response.statusCode,
          'ServerError',
          response.error,
        );
      case EHttpStatusCode.serviceUnavailable:
        throw new HandleError(
          response.statusCode,
          'ServiceUnavailableError',
          response.error,
        );
      default:
        throw new HandleError(
          response.statusCode,
          'ServerError',
          response.error,
        );
    }
  }
}
