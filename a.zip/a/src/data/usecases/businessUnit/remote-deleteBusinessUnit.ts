import { EHttpStatusCode, IHttpClient } from '@/data/protocols/http';
import { HandleError } from '@/domain/errors';
import { IDeleteBusinessUnit } from '@/domain/usecases/businessUnit';

export class RemoteDeleteBusinessUnit implements IDeleteBusinessUnit {
  private readonly httpClient: IHttpClient<void>;
  private readonly url: string;

  constructor(httpClient: IHttpClient, url: string) {
    this.httpClient = httpClient;
    this.url = url;
  }

  async delete(id: number): Promise<void> {
    const response = await this.httpClient.request({
      method: 'delete',
      url: this.url.replace('{id}', id.toString()),
    });
    switch (response.statusCode) {
      case EHttpStatusCode.ok:
        return;
      case EHttpStatusCode.badRequest:
        throw new HandleError(
          response.statusCode,
          'BadRequestError',
          response.error,
        );
      case EHttpStatusCode.unauthorized:
        throw new HandleError(
          response.statusCode,
          'UnauthorizedError',
          response.error,
        );
      case EHttpStatusCode.forbidden:
        throw new HandleError(
          response.statusCode,
          'ForbiddenError',
          response.error,
        );
      case EHttpStatusCode.notFound:
        throw new HandleError(
          response.statusCode,
          'NotFoundError',
          response.error,
        );
      case EHttpStatusCode.methodNotAllowed:
        throw new HandleError(
          response.statusCode,
          'methodNotAllowedError',
          response.error,
        );
      case EHttpStatusCode.serverError:
        throw new HandleError(
          response.statusCode,
          `${response.error?.mensagens[0].mensagem}`,
          response.error,
        );
      case EHttpStatusCode.serviceUnavailable:
        throw new HandleError(
          response.statusCode,
          'ServiceUnavailableError',
          response.error,
        );
      default:
        throw new HandleError(
          response.statusCode,
          'ServerError',
          response.error,
        );
    }
  }
}
