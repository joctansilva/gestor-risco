import { EHttpStatusCode } from '@/data/protocols/http';
import { HandleError } from '@/domain/errors';

export function handleHttpErrors(
  statusCode: EHttpStatusCode,
  error: any,
): void {
  switch (statusCode) {
    case EHttpStatusCode.ok:
      return;
    case EHttpStatusCode.badRequest:
      throw new HandleError(statusCode, 'BadRequestError', error);
    case EHttpStatusCode.unauthorized:
      throw new HandleError(statusCode, 'UnauthorizedError', error);
    case EHttpStatusCode.forbidden:
      throw new HandleError(statusCode, 'ForbiddenError', error);
    case EHttpStatusCode.notFound:
      throw new HandleError(statusCode, 'NotFoundError', error);
    case EHttpStatusCode.methodNotAllowed:
      throw new HandleError(statusCode, 'methodNotAllowedError', error);
    case EHttpStatusCode.serverError:
      throw new HandleError(
        statusCode,
        `${error?.mensagens[0].mensagem}`,
        error,
      );
    case EHttpStatusCode.serviceUnavailable:
      throw new HandleError(statusCode, 'ServiceUnavailableError', error);
    default:
      throw new HandleError(statusCode, 'ServerError', error);
  }
}
