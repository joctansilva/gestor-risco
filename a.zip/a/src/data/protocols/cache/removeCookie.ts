export interface IRemoveCookie {
  remove: (key: string) => void;
}
