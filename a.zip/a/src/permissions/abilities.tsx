import { useLogout } from '@/presentation/hooks';
import { AbilityBuilder, createMongoAbility } from '@casl/ability';

export default function defineAbilityFor(user: string) {
  const { can, build, cannot } = new AbilityBuilder(createMongoAbility);
  const { publicLogout } = useLogout();

  switch (user) {
    case 'SCOPE_COCKPIT_MASTER':
      can('manage', 'all');
      break;
    case 'SCOPE_COCKPIT_BUSINESS':
      can('manage', 'all');
      cannot('updateCredentials', 'all');
      break;
    case 'SCOPE_COCKPIT_SEARCH':
      can('read', 'all');
      break;
    default:
      publicLogout();
  }

  return build();
}
