import { z } from 'zod';

export const selectBusinessUnitSchema = z.object({
  select_business_unit: z.string({
    required_error: 'Esse campo não pode ficar vazio',
  }),
});

export const businessUnitSchema = z.object({
  cd_unit: z.coerce
    .number({
      invalid_type_error: 'Esse campo só aceita números',
    })
    .int('Esse campo só aceita números inteiros')
    .positive('Esse campo só aceita números maiores que 0')
    .max(99999, 'Esse campo não pode ter mais que 5 caracteres'),
  ds_name: z
    .string({
      required_error: 'Esse campo não pode ficar vazio',
    })
    .max(50, 'Esse campo não pode ter mais que 50 caracteres'),
  nr_cnpj: z.string({ required_error: 'Esse campo não pode ficar vazio' }),
  channel: z.string({ required_error: 'Esse campo não pode ficar vazio' }),
  nm_corp_reason: z
    .string()
    .max(150, 'Esse campo não pode ter mais que 150 caracteres')
    .optional()
    .nullable(),
  st_active: z.boolean(),
});

export const businessUnitFilterSchema = z.object({
  ds_name: z.string(),
  nr_cnpj: z.string(),
});

export type TSelectBusinessUnitSchema = z.infer<
  typeof selectBusinessUnitSchema
>;
export type TBusinessUnitSchema = z.infer<typeof businessUnitSchema>;
export type TBusinessUnitFilterSchema = z.infer<
  typeof businessUnitFilterSchema
>;
