export {};

declare global {
  interface Window {
    env: {
      VITE_APPLICATION_ID: string;
      VITE_PUBLIC_API_URL: string;
      VITE_DOMAIN_COOKIE: string;
      VITE_URL_LOGIN: string;
    };
  }
}
