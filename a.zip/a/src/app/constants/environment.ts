import { loadEnv } from '@cvccorp-components/chui-utils';

const env = loadEnv<Window['env']>();

export { env };
