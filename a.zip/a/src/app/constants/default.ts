export const productionEnvironment = process.env.NODE_ENV == 'production';

export const APPLICATION_ID = productionEnvironment
  ? window.env.VITE_APPLICATION_ID
  : process.env.VITE_APPLICATION_ID;

export const PUBLIC_API_URL = productionEnvironment
  ? window.env.VITE_PUBLIC_API_URL
  : process.env.VITE_PUBLIC_API_URL;

export const DOMAIN_COOKIE = productionEnvironment
  ? window.env.VITE_DOMAIN_COOKIE
  : process.env.VITE_DOMAIN_COOKIE;

export const URL_LOGIN = productionEnvironment
  ? window.env.VITE_URL_LOGIN
  : process.env.VITE_URL_LOGIN;

export const PUBLIC_API_URL_LOCAL = process.env.VITE_PUBLIC_API_URL_LOCAL;

export const nameAppTokenCookie = 'appToken-fe-react-risk-analysis';
export const oldNameAppTokenCookie = 'old-appToken-fe-react-risk-analysis';

export const backofficeLogin = `${URL_LOGIN}${DOMAIN_COOKIE}/?applicationId=${APPLICATION_ID}`;

export const documentFormatter = (value: number) => {
  const valueStr = value.toString();
  return valueStr.replace(
    /^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/,
    '$1.$2.$3/$4-$5',
  );
};
