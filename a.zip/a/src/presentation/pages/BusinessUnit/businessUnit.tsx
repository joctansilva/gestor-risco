import { IGetSimplifiedBusinessUnit } from '@/domain/usecases/businessUnit/getSimplifiedBusinessUnit';
import { editCurrentCookie } from '@/main/adapter/currentCookieAdapter';
import ControlledAutocomplete from '@/presentation/components/ControlledAutocomplete';
import Logo from '@/presentation/components/Logo';
import { useCookie } from '@/presentation/hooks/useCookie';
import {
  TSelectBusinessUnitSchema,
  selectBusinessUnitSchema,
} from '@/validation';
import { Button } from '@cvccorp-components/chui-react-components';
import { useForm } from '@cvccorp-components/chui-react-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useQuery } from '@tanstack/react-query';
import React from 'react';
import { useNavigate } from 'react-router';
import * as S from './styles';

interface IBusinessUnitPage {
  getAll: IGetSimplifiedBusinessUnit;
}

export interface IOptions {
  label: string;
  value: string;
  status?: boolean;
}

const BusinessUnit = ({ getAll }: IBusinessUnitPage) => {
  const cookie = useCookie();
  const navigate = useNavigate();

  const { data: selectData, isFetching: loading } = useQuery({
    queryKey: ['selectBusinessUnit'],
    queryFn: () => getAll.get(),
    staleTime: 1000,
    gcTime: 2000,
  });

  let options: IOptions[] = [];
  if (selectData) {
    options = selectData.map(data => {
      return {
        label: data.nm_corp_reason,
        value: `${data.id}-${data.nm_corp_reason}`,
        status: data.st_active,
      };
    });
  }

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<TSelectBusinessUnitSchema>({
    resolver: zodResolver(selectBusinessUnitSchema),
  });

  const onSubmit = (data: TSelectBusinessUnitSchema) => {
    const businessUnitData = data.select_business_unit.split('-');
    const newCookie = {
      ...cookie,
      sq_unit: Number(businessUnitData[0]),
      nm_corp_reason: businessUnitData[1],
    };
    const encodedNewCookie = btoa(JSON.stringify(newCookie));
    editCurrentCookie(encodedNewCookie);
    navigate('/home');
  };
  return (
    <S.Wrapper>
      <S.Container>
        <S.Card>
          <S.LogoWrapper>
            <Logo theme="dark" />
          </S.LogoWrapper>
          <S.Form onSubmit={handleSubmit(onSubmit)}>
            <ControlledAutocomplete
              name="select_business_unit"
              control={control}
              label="Selecione a Unidade de Negócio"
              options={options}
              supportText={
                errors.select_business_unit &&
                errors.select_business_unit.message
              }
              disabled={loading}
            />
            <Button type="submit" loading={loading}>
              Entrar
            </Button>
          </S.Form>
        </S.Card>
      </S.Container>
    </S.Wrapper>
  );
};

export default BusinessUnit;
