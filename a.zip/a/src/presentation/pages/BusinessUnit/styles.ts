import { ChuiTheme } from '@cvccorp-components/chui-react-components';
import styled from '@emotion/styled';

export const Wrapper = styled.div`
  width: 90.25rem;
  margin: 0 auto;
  max-width: 100%;
`;

export const Container = styled.div`
  padding: 2.5rem 0;
  display: flex;
  justify-content: center;
  align-items: center;
`;

export const Card = styled.div<{ theme?: ChuiTheme }>(props => {
  const shadow = props.theme.shadow;
  return {
    background: '#fff',
    width: '500px',
    borderRadius: '0.5rem',
    padding: '4rem',
    boxShadow: shadow.light[100],
  };
});

export const LogoWrapper = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
  padding: 0 0 2rem 0;
`;

export const Form = styled.form`
  display: flex;
  justify-content: center;
  align-items: flex-end;
  flex-direction: column;
  gap: 2rem;
  fieldset {
    width: 100% !important;
  }
`;
