import { Typography } from '@cvccorp-components/chui-react-components';
import React from 'react';
import * as S from './styles';

const Footer = () => {
  return (
    <S.FooterContainer>
      <Typography
        variant="paragraph"
        scale={2}
        weight="regular"
        color="neutral.gray.900"
      >
        ©2022 CVC Corp - Maior grupo de viagens da América Latina.
      </Typography>
    </S.FooterContainer>
  );
};

export default Footer;
