import {
  nameAppTokenCookie,
  oldNameAppTokenCookie,
} from '@/app/constants/default';
import { makeCookieAdapter } from './../factories/cache/cookiesAdapterFactory';

export const setCurrentCookie = () => {
  const oldCookie = makeCookieAdapter().get(oldNameAppTokenCookie);
  if (oldCookie) {
    makeCookieAdapter().set(nameAppTokenCookie, oldCookie);
  }
};

export const getCurrentCookie = () => {
  return makeCookieAdapter().get(nameAppTokenCookie);
};

export const editCurrentCookie = (value: string) => {
  const cookie = makeCookieAdapter().get(nameAppTokenCookie);
  makeCookieAdapter().set(oldNameAppTokenCookie, String(cookie));
  makeCookieAdapter().edit(
    nameAppTokenCookie,
    `eyJ4NXQjUzI1NiI6ImExUG9xdHpROVVQNjdpVUlkSzdsbXRQV2oyLTg5THBOMUZTN3FUa3RwOFEiLCJraWQiOiJjb3JwYXV0aG9yaXphdGlvbnNlcnZlci1kZXYudjIiLCJhbGciOiJSUzI1NiJ9.${value}.PoJPWpeVBknhcyvdkzB1JVXL6ii76lyfDlM-81fbsb09zPbB-gusKaHaiP8e2Xxm5VyW93DLx_vhjtEFeVk5QzgSXHn_HplwxQtLM85kzSOgg3fIuQ8R3MeBFD1OMifnYV-AKKMlYQLfMICV1u48i0NpC520D8aNqp6ydYhzrJsSO6RHUFiJ9sgwvnUEYN8JggBIpqOJWYfGCPx4YST7NiEnxsMzoFlVQnDs2dsVFK0blMelhAaDuL-W3va8L0pg6ViFTocIdrDKxPk_pIlmd-Tc5vWL-YPvDfcxBsLrHeTl9cvcxcHgpA0omakb04S_j9sbbLNRV2enIKSm3kA3Mg`,
  );
};

export const removeCurrentCookie = () => {
  makeCookieAdapter().remove(nameAppTokenCookie);
  makeCookieAdapter().remove(oldNameAppTokenCookie);
};
