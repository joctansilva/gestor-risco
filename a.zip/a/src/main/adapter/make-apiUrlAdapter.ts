import { ApiUrlAdapter } from '@/infra/adapter';

export const makeApiUrlAdapter = () => {
  return new ApiUrlAdapter();
};
