import { backofficeLogin } from '@/app/constants/default';
import { useCookie } from '@/presentation/hooks/useCookie';
import React from 'react';
import { Navigate } from 'react-router-dom';

export interface IRoute {
  Component: JSX.Element;
}

const PrivateRoute = ({ Component }: IRoute) => {
  const cookie = useCookie();
  const user = cookie?.sub;
  const sqUnit = cookie?.sq_unit;

  // if (cookie) {
  //   if (user && !sqUnit) {
  //     return <Navigate to="/" replace />;
  //   }
  //   return Component;
  // } else {
  //   window.location.href = backofficeLogin;
  // }
  return Component;
};

export default PrivateRoute;
