import { createBrowserRouter, Navigate } from 'react-router-dom';
import React from 'react';
import PublicRoute from '../proxies/publicRoute';
import Layout from '@/presentation/components/Layout';
import MakeBusinessUnit from '../factories/pages/makeBusinessUnit';
import PrivateRoute from '../proxies/privateRoute';
import MakeHome from '../factories/pages/makeHome';

const router = createBrowserRouter([
  {
    id: 'select_business_unit',
    element: <Layout />,
    children: [
      {
        path: '/',
        element: <PublicRoute Component={<MakeBusinessUnit />} />,
      },
    ],
    errorElement: <Navigate to="/" />,
  },
  {
    id: 'home',
    element: <Layout />,
    loader: () => {
      return {
        name: 'home',
      };
    },
    children: [
      {
        path: '/home',
        element: <PrivateRoute Component={<MakeHome />} />,
      },
    ],
  },
]);

export default router;
