import BusinessUnit from '@/presentation/pages/BusinessUnit/businessUnit';
import React from 'react';
import { makeRemoteGetSimplifiedBusinessUnit } from '../usecases/businessUnit';

const MakeBusinessUnit = () => {
  return <BusinessUnit getAll={makeRemoteGetSimplifiedBusinessUnit()} />;
};

export default MakeBusinessUnit;
