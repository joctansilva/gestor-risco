import { RemoteUpdateBusinessUnit } from '@/data/usecases/businessUnit';
import { IUpdateBusinessUnit } from '@/domain/usecases/businessUnit';
import { makeApiUrlAdapter } from '@/main/adapter';
import { makeAxiosHttpClientAdapter } from '../../http';

export const makeRemoteUpdateBusinessUnit = (): IUpdateBusinessUnit => {
  return new RemoteUpdateBusinessUnit(
    makeAxiosHttpClientAdapter(),
    makeApiUrlAdapter().getUrl('/businessUnit'),
  );
};
