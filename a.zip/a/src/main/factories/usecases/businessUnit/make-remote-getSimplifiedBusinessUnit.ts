import { RemoteGetSimplifiedBusinessUnit } from '@/data/usecases/businessUnit';
import { IGetSimplifiedBusinessUnit } from '@/domain/usecases/businessUnit/getSimplifiedBusinessUnit';
import { makeApiUrlAdapter } from '@/main/adapter';
import { makeAxiosHttpClientAdapter } from '../../http';

export const makeRemoteGetSimplifiedBusinessUnit =
  (): IGetSimplifiedBusinessUnit => {
    return new RemoteGetSimplifiedBusinessUnit(
      makeAxiosHttpClientAdapter(),
      makeApiUrlAdapter().getUrl('/businessUnit/simplified'),
    );
  };
