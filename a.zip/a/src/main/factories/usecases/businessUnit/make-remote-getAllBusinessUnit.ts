import { RemoteGetAllBusinessUnit } from '@/data/usecases/businessUnit';
import { IGetAllBusinessUnit } from '@/domain/usecases/businessUnit';
import { makeApiUrlAdapter } from '@/main/adapter';
import { makeAxiosHttpClientAdapter } from '../../http';

export const makeRemoteGetAllBusinessUnit = (): IGetAllBusinessUnit => {
  return new RemoteGetAllBusinessUnit(
    makeApiUrlAdapter().getUrl('/businessUnit?{params}'),
    makeAxiosHttpClientAdapter(),
  );
};
