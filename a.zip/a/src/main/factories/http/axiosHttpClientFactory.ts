import { type IHttpClient } from '@/data/protocols/http';
import { AxiosHttpClient } from '@/infra/http/axios-http-client';

export const makeAxiosHttpClientAdapter = (): IHttpClient => {
  return new AxiosHttpClient();
};
