import { DOMAIN_COOKIE } from '@/app/constants/default';
import { IGetCookie, IRemoveCookie, ISetCookie } from '@/data/protocols/cache';
import { IEditCookie } from '@/data/protocols/cache/editCookie';
import Cookies from 'js-cookie';

export class CookieAdapter
  implements ISetCookie, IGetCookie, IRemoveCookie, IEditCookie
{
  set(key: string, value: string): void {
    Cookies.set(key, value, {
      expires: 2,
      domain: '127.0.0.1',
      // domain: DOMAIN_COOKIE,
    });
  }

  get(key: string): string | undefined {
    return Cookies.get(key);
  }

  edit(key: string, value: string) {
    this.remove(key);
    this.set(key, value);
  }

  remove(key: string): void {
    Cookies.set(key, '', {
      expires: -1,
      domain: '127.0.0.1',
      // domain: DOMAIN_COOKIE,
    });
    Cookies.remove(key, {
      domain: '127.0.0.1',
      // domain: DOMAIN_COOKIE,
    });
  }
}
