import {
  PUBLIC_API_URL,
  PUBLIC_API_URL_LOCAL,
  productionEnvironment,
} from '@/app/constants/default';

export class ApiUrlAdapter {
  getUrl(path: string): string {
    return `${
      productionEnvironment ? PUBLIC_API_URL : PUBLIC_API_URL_LOCAL
    }${path}`;
  }
}
