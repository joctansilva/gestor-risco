import "@emotion/react";
import { ChuiTheme } from "@cvccorp-components/chui-react-components/provider/models/chui-theme";
declare module "@emotion/react" {
  // eslint-disable-next-line @typescript-eslint/no-empty-object-type
  export interface Theme extends ChuiTheme {}
  export function useTheme<T = ChuiTheme>(): T;
}
